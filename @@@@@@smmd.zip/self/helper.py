# نسخه جدید دیباگ : 3
# صفر تا صد توسط @U3erZX دیباگ شده 
# اگه ننت خراب نیست اسکی میری منبع بزن
from pyrogram import Client, filters, idle, errors
from pyrogram.types import *
from pyrogram.raw import functions, base, types
from colorama import Fore
import requests
import pymysql
import json
import sys
import os
import re
#================= Config =================#
owner = 7074367029 # ایدی عددی مالک سلف ساز
api_id = 26154106 # ایپی ایدی مالک سلف ساز 
api_hash = "86490b8b2b82b69a2eb012b9b20e4788" # ایپی هش مالک سلف ساز
bot_token = "8437955735:AAHvVQuZR8gIvZ8hjvBdKsYAmDQlRtpLHL0" # توکن ربات هلپر 
DBName = "xxxxxxxx_mmdss" # نام دیتابیس هلپر 
DBUser = "xxxxxxxx_mmdss" # یوزر دیتابیس هلپر 
DBPass = "xxxxxxxx_mmdss" # پسورد دیتابیس هلپر 

# دیتابیس اصلی برای گرفتن الماس کاربران
MAIN_DBName = "xxxxxxxx_mmdbots" # نام دیتابیس اصلی از سورس اصلی
MAIN_DBUser = "xxxxxxxx_mmdbots" # یوزر دیتابیس اصلی
MAIN_DBPass = "xxxxxxxx_mmdbots" # پسورد دیتابیس اصلی
#==========================================#

def get_data(query, params=None):
    try:
        connection = pymysql.connect(
            host="localhost",
            database=DBName,
            user=DBUser,
            password=DBPass,
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=True,
            connect_timeout=5,
            read_timeout=10,
            write_timeout=10,
        )
        db = connection.cursor()
        if params is None:
            m = re.match(r"^\s*SELECT\s+\*\s+FROM\s+(\w+)\s+WHERE\s+id\s*=\s*'?([0-9]+)'?\s*(LIMIT\s+1)?\s*$", query, re.IGNORECASE)
            if m:
                table, _id, _ = m.groups()
                query = f"SELECT * FROM {table} WHERE id = %s LIMIT 1"
                params = (_id,)
        db.execute(query, params or ())
        return db.fetchone()
    except Exception as e:
        print(f"[DB][get_data] Error: {type(e).__name__}: {e}")
        return None
    finally:
        try:
            connection.close()
        except Exception:
            pass


def get_datas(query):
     with pymysql.connect(host="localhost", database=DBName, user=DBUser, password=DBPass) as connect:
          db = connect.cursor()
          db.execute(query)
          result = db.fetchall()
          return result

def update_data(query):
     with pymysql.connect(host="localhost", database=DBName, user=DBUser, password=DBPass) as connect:
          db = connect.cursor()
          db.execute(query)
          connect.commit()

# تابع برای گرفتن الماس از دیتابیس اصلی
def get_main_data(query, params=None):
    try:
        connection = pymysql.connect(
            host="localhost",
            database=MAIN_DBName,
            user=MAIN_DBUser,
            password=MAIN_DBPass,
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=True,
            connect_timeout=5,
            read_timeout=10,
            write_timeout=10,
        )
        db = connection.cursor()
        db.execute(query, params or ())
        return db.fetchone()
    except Exception as e:
        print(f"[MAIN_DB][get_main_data] Error: {type(e).__name__}: {e}")
        return None
    finally:
        try:
            connection.close()
        except Exception:
            pass

# تابع برای گرفتن اطلاعات کاربر از دیتابیس اصلی
def get_user_diamonds(user_id):
    """گرفتن الماس کاربر از دیتابیس اصلی"""
    try:
        user_data = get_main_data(f"SELECT amount FROM user WHERE id = '{user_id}' LIMIT 1")
        if user_data:
            return user_data.get('amount', 0)
        return 0
    except Exception as e:
        print(f"[get_user_diamonds] Error: {e}")
        return 0

update_data("""
CREATE TABLE IF NOT EXISTS user(
id bigint PRIMARY KEY,
step varchar(150) DEFAULT 'none'
) default charset=utf8mb4;
""")
update_data("""
CREATE TABLE IF NOT EXISTS ownerlist(
id bigint PRIMARY KEY
) default charset=utf8mb4;
""")
update_data("""
CREATE TABLE IF NOT EXISTS adminlist(
id bigint PRIMARY KEY
) default charset=utf8mb4;
""")

OwnerUser = get_data(f"SELECT * FROM ownerlist WHERE id = '{owner}' LIMIT 1")
if OwnerUser is None:
     update_data(f"INSERT INTO ownerlist(id) VALUES({owner})")

AdminUser = get_data(f"SELECT * FROM adminlist WHERE id = '{owner}' LIMIT 1")
if AdminUser is None:
     update_data(f"INSERT INTO adminlist(id) VALUES({owner})")

app = Client("Helper", api_id, api_hash, bot_token=bot_token)

@app.on_message(filters.private, group=-1)
async def update(c, m):
     OwnerUser = get_data(f"SELECT * FROM ownerlist WHERE id = '{m.chat.id}' LIMIT 1")
     AdminUser = get_data(f"SELECT * FROM adminlist WHERE id = '{m.chat.id}' LIMIT 1")
     if OwnerUser is not None or AdminUser is not None:
          user = get_data(f"SELECT * FROM user WHERE id = '{m.chat.id}' LIMIT 1")
          if user is None:
               update_data(f"INSERT INTO user(id) VALUES({m.chat.id})")
  
# ==================== متن‌های راهنما (نسخه جذاب و مرتب) ==================== #

# ==================== دکمه‌های جدید ==================== #

help_antilogin = """
╔═════ 🔐 ضد لاگین ═════╗

از ورود غیرمجاز به اکانتت جلوگیری کن!

─────────────────────

➤ `ضد لاگین روشن`  
✅ هر لاگین جدید رو خودکار بلاک می‌کنه

➤ `ضد لاگین خاموش`
❌ سیستم ضد لاگین غیرفعال میشه

─────────────────────
"""

help_online = """
╔═══════ 🟢 انلاینی ═══════╗

با این بخش میتونید همیشه اکانتونو آنلاین نگه دارید

─────────────────────

➤ `انلاینی روشن`
✅ با این دستور همیشه آنلاین باش

➤ `انلاینی خاموش`
❌ وضعیت آنلاین غیرفعال میشه

─────────────────────
"""

help_clone = """
╔═════ 🧬 کلون ═════╗

با این دستور میتونید پروفایل هر شخصی رو کپی کنید!

─────────────────────

➤ `کلون` + ریپلای  
🧑‍💻 عکس، اسم، بیو و اطلاعات کاربر کپی میشه

─────────────────────
"""

help_delete = """
╔═════ 🗑 حذف پیام انبوه ═════╗

چندتا پیام آخر چت رو سریع پاک کن!

─────────────────────

➤ `حذف` [تعداد]  
🧹 به تعداد مشخص پیام‌ها حذف میشن

➤ `حذف` + ریپلای
🧹 با این دستور پیامی ک ریپلای میکنی روش رو پاک کن

─────────────────────
"""

help_animation = """
╔═══════ 🎮 سرگرمی ═══════╗

دستورهای فان و باحال برای چت 😎

─────────────────────

➤ `.جق`
➤ `.moon`
➤ `.clock`
➤ `.thunder`
➤ `.earth`
➤ `.heart`
➤ `.love`
➤ `.santet`
➤ `.nah`
➤ `.ajg`
➤ `.babi`
➤ `.tank`
➤ `.y`
➤ `.awk`
➤ `.tembak`
➤ `.heli`
➤ `.gabut`
➤ `.syg`
➤ `.dino`
➤ `.hack`
➤ `.fuck`
➤ `.charging`
➤ `.gang`
➤ `.hypo`
➤ `.ding`
➤ `.wtf`
➤ `.call`
➤ `.bomb`
➤ `.brain`
➤ `.ahh`
➤ `.hmm`

─────────────────────
"""

help_saat = """
╔═══════ 🕒 ساعت کنار اسم و بیو ═══════╗

ساعت رو با فونت‌های خفن کنار اسمت یا توی بیو نشون بده  
فوق‌العاده شیک و خاص میشه اکانتت!

─────────────────────

➤ `ساعت روشن`  
✅ ساعت کنار اسم فعال میشه

➤ `ساعت خاموش`  
❌ ساعت کنار اسم خاموش میشه

─────────────────────

➤ `ساعت بیو روشن`  
✅ ساعت توی بیو فعال میشه

➤ `ساعت بیو خاموش`  
❌ ساعت از بیو حذف میشه

➤ `ثبت بیو`
🆔 با این دستور میتونید بیو ثبت کنید و ساعت هم کنارش بیاد
─────────────────────

➤ `فونت ساعت` [عدد]  
🎨 فونت ساعت رو عوض کن  
(عدد بین ۱ تا ۴۹)

─────────────────────

📜 لیست فونت‌ها (نمونه ۰۱:۲۳):

(1) 𝟷𝟸:𝟹𝟺
(2) ①②:③④
(3) 𝟭𝟮:𝟯𝟰
(4) ١٢:٣٤
(5) １２:３４
(6) ₁₂:₃₄
(7) ¹²:³⁴
(8) 𝟏𝟐:𝟑𝟒
(9) 𝟙𝟚:𝟛𝟜
(10) ❶❷:❸❹

─────────────────────
"""

help_bal_saat = """
╔═══════ 🪽 بال ساعت کنار اسم ═══════╗

بال‌های خفن و فانتزی رو دور ساعت اسمت بذار  
اکانتت خیلی لاکچری و متفاوت میشه!

─────────────────────

➤ `بال` [عدد]  
🎯 یکی از ۱۹۴ بال خفن رو انتخاب کن

➤ `بال خاموش`  
🚫 بال رو کامل حذف کن

─────────────────────

📜 لیست بال‌ها (نمونه):

1: ❰ ⩇⩇:⩇⩇ ❱
2: ✧ ⩇⩇:⩇⩇ ✧
3: 𓆩 ⩇⩇:⩇⩇ 𓆪
4: ❦ ⩇⩇:⩇⩇ ❦
5: ᥫ᭡ ⩇⩇:⩇⩇ ᥫ᭡
6: ♛ ⩇⩇:⩇⩇ ♛
7: ༒︎ ⩇⩇:⩇⩇ ༒︎
8: ⨺⃝ ⩇⩇:⩇⩇ ⨺⃝
9: ۝ ⩇⩇:⩇⩇ ۝
10: ߷ ⩇⩇:⩇⩇ ߷

─────────────────────
"""

help_riket = """
╔═══════ ریکت خودکار ═══════╗

هر کی بهت پیام بده یا توی گروه چیزی بفرسته،  
خودکار ریکت دلخواهت رو براش بذار!

─────────────────────

➤ `ریکت روشن`  
✅ ریکت خودکار فعال میشه

➤ `ریکت خاموش`  
❌ ریکت خودکار خاموش میشه

─────────────────────

➤ `ریکت` [ایموجی] + ریپلای  
❤️ ریکت دلخواه رو برای اون کاربر تنظیم کن

➤ `حذف ریکت` + ریپلای  
🗑 ریکت تنظیم‌شده رو پاک کن

─────────────────────

➤ `لیست ریکت`  
📋 همه کاربرایی که ریکت دادی رو نشون میده

➤ `پاکسازی لیست ریکت`  
🧹 کل لیست رو صفر کن

─────────────────────
"""

help_spam = """
╔═══════ 🚀 اسپم پیام ═══════╗

پیامتو انقدر تکرار کن که طرف دیوونه بشه 😈

─────────────────────

➤ `اسپم` [تعداد] [متن]  
📨 پیام رو به تعداد دلخواه تکرار می‌کنه

➤ `اسپم سریع` [تعداد] [متن]  
⚡ با سرعت وحشتناک اسپم می‌کنه (۰.۰۱ ثانیه فاصله)

─────────────────────
"""

help_download = """
╔═══════ دانلودر و کپی پست ═══════╗

هر پستی که بخوای از هر کانال یا گروهی دانلود کن یا کپی کن توی سیو مسیجت

─────────────────────

➤ `دانلود` [لینک پست]  
⬇️ اگر مدیا باشه دانلود می‌کنه، اگر متن باشه کپی می‌کنه

─────────────────────
"""

help_logo = """
╔═══════ 🎨 ساخت لوگو ═══════╗

با اسم انگلیسی و یه طرح خفن، تو چند ثانیه لوگو بساز!

─────────────────────

➤ `لوگو` [اسم انگلیسی] [عدد طرح]  
مثال: `لوگو ALI 1`  
→ لوگو با اسم ALI و طرح شماره ۱ ساخته میشه

─────────────────────
"""

help_game = """
╔═══════ 🎲 تقلب در بازی‌های تلگرام ═══════╗

هر چی دلت خواست تو تاس، دارت، بولینگ و ... برنده شو!

─────────────────────

➤ `تاس` [عدد ۱-۶]  
🎲 همیشه همون عدد رو میاره

➤ `دارت`  
🎯 همیشه وسط می‌زنه (بهترین امتیاز)

➤ `بولینگ`  
🎳 همیشه استرایک می‌زنه

➤ `بسکتبال`  
🏀 همیشه گل می‌کنه

➤ `فوتبال` [۱ یا ۴]  
⚽ ۴ = گل | ۱ = بیرون

➤ `کازینو`  
🎰 همیشه ۷۷۷ میاره (جک‌پات)

─────────────────────
"""

help_convert = """
╔═══════ تبدیل ها مدیا ═══════╗

استیکر، عکس، گیف رو به هم تبدیل کن!

─────────────────────

➤ استیکر → عکس  
ریپلای روی استیکر + دستور تبدیل

➤ عکس → استیکر  
ریپلای روی عکس + تبدیل به استیکر

➤ عکس → گیف  
ریپلای روی عکس + تبدیل به گیف

─────────────────────
"""

help_management = """
╔═══════ 🛡️ مدیریت اکانت ═══════╗

کاربرای مزاحم رو کنترل کن!

─────────────────────

➤ `بلاک` + ریپلای  
🚫 کاربر رو بلاک کن

➤ `انبلاک` + ریپلای  
✅ کاربر رو آزاد کن

─────────────────────
"""

help_sakot = """
╔═══════ سکوت کردن کاربر ═══════╗

پیامای طرف رو خودکار حذف کن!

─────────────────────

➤ `سکوت` + ریپلای  
🤐 کاربر رو ساکت کن

➤ `حذف سکوت` + ریپلای  
🗣 دوباره آزادش کن

─────────────────────

➤ `لیست سکوت`  
📋 کی‌ها ساکت شدن؟

➤ `پاکسازی لیست سکوت`  
🧹 همه رو آزاد کن

─────────────────────
"""

help_enemy_friend = """
╔═══════ 😈 دشمن و دوست ═══════╗

دشمناتو اذیت کن، دوستاتو خوشحال!

─────────────────────

**دشمن:**
➤ `تنظیم دشمن` + ریپلای  
☠️ به لیست دشمن اضافه کن

➤ `حذف دشمن` + ریپلای  
🗑 از لیست دشمن پاک کن

➤ `لیست دشمن`  
📋 دشمنای فعلی

➤ `پاکسازی لیست دشمن`  
💥 همه دشمنا حذف

─────────────────────

**دوست:**
➤ `تنظیم دوست` + ریپلای  
💞 به لیست دوستان اضافه کن

➤ `حذف دوست` + ریپلای  
🗑 از لیست دوستان پاک کن

➤ `لیست دوست`  
📋 دوستای فعلی

➤ `پاکسازی لیست دوست`  
💖 همه دوستان حذف

─────────────────────
"""

help_pvlock = """
╔═══════ 🔒 قفل‌ها ═══════╗

این قابلیت ساخته شده تا شما احساس راحتی داشته کنید

─────────────────────

➤ `قفل پیوی روشن`  
🔐 دیگه کسی نمیتونه بهت پیام بده

➤ `قفل پیوی خاموش`  
🔓 همه می‌تونن پیام بدن

─────────────────────
"""

help_secretary = """
╔═══════ منشی پیشرفته ═══════╗

هر کی بهت پیام داد، خودکار جواب بده!

─────────────────────

➤ `منشی روشن`  
✅ منشی فعال میشه

➤ `منشی خاموش`  
❌ منشی خاموش میشه

➤ `تایم منشی ` [ثانیه]
⏳ تنظیم زمان پاسخ منشی به ثانیه

➤ `متن منشی` [متن دلخواه]  
📝 متن جواب خودکار رو تنظیم کن

─────────────────────
"""

help_filter = """
╔═══════ فیلترکلمات ═══════╗

کلمات ممنوعه رو حذف کن!

─────────────────────

➤ `فیلتر کلمات روشن`  
✅ فیلتر فعال میشه

➤ `فیلتر کلمات خاموش`  
❌ فیلتر غیرفعال میشه

─────────────────────

➤ `فیلتر کلمه` [کلمه]  
➕ کلمه جدید اضافه کن

➤ `حذف فیلتر` [کلمه]  
➖ کلمه رو از لیست بردار

─────────────────────

➤ `لیست فیلتر`  
📋 کلمات فیلتر شده

➤ `پاکسازی کلمات فیلتر`  
🧹 همه کلمات رو پاک کن

─────────────────────
"""

help_timesave = """
╔═══════ 📸 ذخیره تایمی ═══════╗

عکس و ویدیوهای تایم‌دار رو خودکار سیو کن!

─────────────────────

➤ `ذخیره تایمی روشن`  
✅ ذخیره خودکار فعال

➤ `ذخیره تایمی خاموش`  
❌ ذخیره خودکار خاموش

─────────────────────
"""

help_texteffect = """
╔═══════ حالت‌متن ═══════╗

پیامات رو با افکت‌های خفن بفرست!

─────────────────────

➤ `افکت متن روشن`  
✅ افکت فعال میشه

➤ `افکت متن خاموش`  
❌ افکت غیرفعال میشه

─────────────────────

➤ `نوع افکت` [نام افکت]  
🎭 افکت رو عوض کن  
(بولد، ایتالیک، زیرخط، اسپویلر، نقل قول، تدریجی، تایپ)

─────────────────────
"""

help_autoseen = """
╔═══════ سین خودکار ═══════╗

هر پیامی که بیاد، خودکار سین بشه!

─────────────────────

➤ `سین خودکار روشن`  
✅ سین خودکار فعال

➤ `سین خودکار خاموش`  
❌ سین خودکار خاموش

─────────────────────
"""

help_action = """
╔═══════ 🎭 اکشن چت ═══════╗

وقتی تایپ می‌کنی، اکشن خفن نشون بده!

─────────────────────

➤ `اکشن روشن`  
✅ اکشن فعال میشه

➤ `اکشن خاموش`  
❌ اکشن خاموش میشه

─────────────────────

➤ `حالت اکشن` [نوع]  
🎯 نوع اکشن رو انتخاب کن  
(تایپ، ویس، ویدیو، عکس، سند، استیکر، بازی)

─────────────────────
"""

help_tabchi = """
╔═══════ تبچی پیشرفته ═══════╗

بنر هاتو راحت و بدون دردسر تبلغ کن با این قابلیت !

─────────────────────

➤ `تبچی روشن`  
✅ تبچی فعال میشه

➤ `تبچی خاموش`  
❌ تبچی و ارسال متوقف میشه

─────────────────────

➤ `بنر` [ثانیه] [فور|کپی] + ریپلای  
➕ بنر جدید اضافه کن (فاصله زمانی به ثانیه)

➤ `لیست بنر`  
📋 همه بنرهای ثبت‌شده

➤ `پاک کردن بنر` [کد بنر]  
🗑 بنر خاص رو حذف کن

➤ `پاکسازی کل تبچی`  
💥 همه بنرها پاک میشن و تبچی خاموش میشه

─────────────────────
"""

help_tools = """
╔═══════ 🛠 ابزارهای جانبی ═══════╗

ابزارهای کاربردی و باحال سلف

─────────────────────

➤ `پینگ`  
⚡ سرعت پاسخ‌دهی سلف رو چک کن

➤ `ایدی` + ریپلای  
🆔 تمام اطلاعات کاربر (اسم، آیدی، یوزرنیم و ...) رو نشون میده

➤ `بیو`  
📝 دریافت بیوگرافی رندوم

➤ `خاطرع`  
😈 دریافت خاطره رندوم

➤ `تگ ادمین`  
👑 ادمین‌های گروه رو تگ کن

➤ `تگ اعضا`  
👥 تا ۱۰۰ نفر از اعضای گروه رو تگ کن

─────────────────────
"""

help_info = """
╔═════════▣═════════╗

این دستور فقط برای ادمین و مالک است
————————————
➤ `تگ ادمین`  
👑 ادمین‌های گروه رو تگ کن

➤ `تگ اعضا`  
👥 تا ۱۰۰ نفر از اعضای گروه رو تگ کن

─────────────────────
"""

# ==================== پنل اصلی جدید با دو بخش ==================== #

openpanelbot = InlineKeyboardMarkup(
     [
         [
             InlineKeyboardButton("پنل 📱", switch_inline_query_current_chat='panel')
         ]
     ]
)

keyboard_idk = ReplyKeyboardMarkup(
     [
         [
             ("Add Admin"),
             ("Delete Admin"),
             ("Admin List")
         ],
         [
             ("Add Owner"),
             ("Delete Owner"),
             ("Owner List")
         ]
     ],
one_time_keyboard=True,resize_keyboard=True)

@app.on_inline_query()
async def answer(client, inline_query):
     chat_id = inline_query.from_user.id
     
     # حذف شرط ادمین بودن - همه کاربران می‌توانند پنل را ببینند
     if inline_query.query == "panel":
          user_id = str(inline_query.from_user.id)  # این خط را اضافه کنید
          
          # پنل اصلی جدید با دو بخش
          panel_buttons = InlineKeyboardMarkup(
               [
                    # ردیف اول: دو بخش اصلی
                    [
                         InlineKeyboardButton("دستورات سلف ⚙️", callback_data=f'self_commands-{user_id}')
                    ],
                    # ردیف آخر: دکمه بستن
                    [
                         InlineKeyboardButton("✖️ بستن پنل", callback_data=f'closepanel-{inline_query.from_user.id}')
                    ]
               ]
          )

          await inline_query.answer(
               results=[
                    InlineQueryResultArticle(
                         title="پنل مدیریت سلف",
                         input_message_content=InputTextMessageContent("**🎛️ پنل مدیریت سلف**\n\nیکی از گزینه‌ها را انتخاب کنید:"),
                         description="پنل مدیریت با دو بخش اصلی",
                         thumb_url="https://telegra.ph/file/7a3b0c5c5c9d2b2b2b2b2.png",
                         reply_markup=panel_buttons
                    ),
               ],
               cache_time=1
          )

     elif inline_query.query == "coinprice":
          try:
               s = requests.get('https://api.nobitex.ir/market/stats?srcCurrency=usdt,trx,ton,btc,shib,eth,etc,usdt,ada,bch,ltc,bnb&dstCurrency=irt,rls,usdt')
               s = s.text
               js = json.loads(s)
               byusdt = js['stats']['usdt-irt']['bestBuy']
               sellusdt = js['stats']['usdt-irt']['bestSell']
               bytrx = js['stats']['trx-irt']['bestBuy']
               selltrx = js['stats']['trx-irt']['bestSell']
               byton = js['stats']['ton-irt']['bestBuy']
               sellton = js['stats']['ton-irt']['bestSell']
               byshib = js['stats']['shib-usdt']['bestBuy']
               sellshib = js['stats']['shib-usdt']['bestSell']
               bybit = js['stats']['btc-usdt']['bestBuy']
               sellbit = js['stats']['btc-usdt']['bestSell']
               byet = js['stats']['eth-usdt']['bestBuy']
               sellet = js['stats']['eth-usdt']['bestSell']
               byetc = js['stats']['etc-usdt']['bestBuy']
               selletc = js['stats']['etc-usdt']['bestSell']
               byada = js['stats']['ada-usdt']['bestBuy']
               sellada = js['stats']['ada-usdt']['bestSell']
               bybch = js['stats']['bch-usdt']['bestBuy']
               sellbch = js['stats']['bch-usdt']['bestSell']
               byltc = js['stats']['ltc-usdt']['bestBuy']
               sellltc = js['stats']['ltc-usdt']['bestSell']
               bybnb = js['stats']['bnb-usdt']['bestBuy']
               sellbnb = js['stats']['bnb-usdt']['bestSell']

               coind = InlineKeyboardMarkup(
                    [
                         [
                              InlineKeyboardButton("Currency", callback_data="outside"),
                              InlineKeyboardButton("Best Buy", callback_data="outside"),
                              InlineKeyboardButton("Best Sell", callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("USDT", callback_data="outside"),
                              InlineKeyboardButton("☫%s" % byusdt, callback_data="outside"),
                              InlineKeyboardButton("☫%s" % sellusdt, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("TRX", callback_data="outside"),
                              InlineKeyboardButton("☫%s" % bytrx, callback_data="outside"),
                              InlineKeyboardButton("☫%s" % selltrx, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("TON", callback_data="outside"),
                              InlineKeyboardButton("☫%s" % byton, callback_data="outside"),
                              InlineKeyboardButton("☫%s" % sellton, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("SHIB", callback_data="outside"),
                              InlineKeyboardButton("$%s" % byshib, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellshib, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("BTC", callback_data="outside"),
                              InlineKeyboardButton("$%s" % bybit, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellbit, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("ETH", callback_data="outside"),
                              InlineKeyboardButton("$%s" % byet, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellet, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("ETC", callback_data="outside"),
                              InlineKeyboardButton("$%s" % byetc, callback_data="outside"),
                              InlineKeyboardButton("$%s" % selletc, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("ADA", callback_data="outside"),
                              InlineKeyboardButton("$%s" % byada, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellada, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("BCH", callback_data="outside"),
                              InlineKeyboardButton("$%s" % bybch, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellbch, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("LTC", callback_data="outside"),
                              InlineKeyboardButton("$%s" % byltc, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellltc, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("BNB", callback_data="outside"),
                              InlineKeyboardButton("$%s" % bybnb, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellbnb, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("Close ×", callback_data=f'Close-{inline_query.from_user.id}')
                         ]
                    ]
               )

               await inline_query.answer(
                    results=[
                         InlineQueryResultArticle(
                              title="Coin price",
                              input_message_content=InputTextMessageContent("➣ **Currency price list**"),
                              url="https://t.me/KING_MEMBEER",
                              description="ᴄʀɪᴛᴜs",
                              thumb_url="https://t.me/KING_MEMBEER/33",
                              reply_markup=coind
                         ),
                    ],
                    cache_time=1
               )
          except:
               pass

@app.on_callback_query()
async def call(app, call):
     # حذف شرط AdminUser - همه کاربران می‌توانند از پنل استفاده کنند
     if call.data != "outside":
          if int(call.from_user.id) == int(call.data.split("-")[1]):
               callback_type = call.data.split("-")[0]
               user_id = call.data.split("-")[1]  # اینجا user_id تعریف می‌شود
               
               # ============ پنل حساب کاربری ============
               if callback_type == "user_account":
                    # دریافت اطلاعات کاربر از تلگرام
                    try:
                         user_info = await app.get_users(user_id)
                         user_first_name = user_info.first_name
                         user_username = f"@{user_info.username}" if user_info.username else "ندارد"
                    except:
                         user_first_name = "کاربر"
                         user_username = "ندارد"
                    
                    # دریافت الماس از دیتابیس اصلی
                    user_diamonds = get_user_diamonds(user_id)
                    
                    # ایجاد متن اطلاعات کاربر
                    account_info = f"""
› 👤 اطلاعات حساب کاربری

› - نام: {user_first_name}
› - یوزرنیم: {user_username}
› - آیدی عددی: `{user_id}`
› - موجودی الماس: {user_diamonds} 💎
                    """
                    
                    # دکمه بازگشت
                    back_button = InlineKeyboardMarkup(
                         [
                              [
                                   InlineKeyboardButton("» بازگشت", callback_data=f'backtopanel-{user_id}')
                              ]
                         ]
                    )
                    
                    await app.edit_inline_text(inline_message_id=call.inline_message_id, text=account_info, reply_markup=back_button)
               
               # ============ پنل دستورات سلف ============
               elif callback_type == "self_commands":
                    # صفحه قابلیت‌ها با چیدمان شبیه تصویر
                    commands_buttons = InlineKeyboardMarkup(
                         [
                              # ردیف اول
                              [
                                   InlineKeyboardButton("ساعت", callback_data=f'saat-{user_id}'),
                                   InlineKeyboardButton("ریکت", callback_data=f'riket-{user_id}'),
                                   InlineKeyboardButton("اسپم", callback_data=f'spam-{user_id}')
                              ],
                              # ردیف سوم
                              [
                                   InlineKeyboardButton("بلاک", callback_data=f'management-{user_id}'),
                                   InlineKeyboardButton("سکوت", callback_data=f'sakot-{user_id}')
                              ],
                              # ردیف چهارم
                              [
                                   InlineKeyboardButton("دوست‌و‌دشمن", callback_data=f'enemyfriend-{user_id}'),
                                   InlineKeyboardButton("قفل پیوی", callback_data=f'pvlock-{user_id}'),
                                   InlineKeyboardButton("منشی", callback_data=f'secretary-{user_id}')
                              ],
                              # ردیف پنجم
                              [
                                   InlineKeyboardButton("حالت‌متن", callback_data=f'texteffect-{user_id}'),
                                   InlineKeyboardButton("تـبـچـی", callback_data=f'tabchi-{user_id}'),
                                   InlineKeyboardButton("ابزار‌ها", callback_data=f'tools-{user_id}')
                              ],
                              # ردیف ششم
                              [
                                   InlineKeyboardButton("سین خودکار", callback_data=f'autoseen-{user_id}'),
                                   InlineKeyboardButton("اکشن", callback_data=f'action-{user_id}'),
                                   InlineKeyboardButton("پینگ", callback_data=f'diamond-{user_id}')
                              ],
                              # ردیف آخر: دکمه بازگشت
                              [
                                   InlineKeyboardButton("» بازگشت", callback_data=f'backtopanel-{user_id}')
                              ]
                         ]
                    )
                    
                    await app.edit_inline_text(inline_message_id=call.inline_message_id, text="**› 𝑷𝒂𝒏𝒆𝒍 𝑺𝒆𝒍𝒇 𝐊𝐀𝐏𝐈**", reply_markup=commands_buttons)
               
               # ============ بازگشت به پنل اصلی ============
               elif callback_type == "backtopanel":
                    # پنل اصلی جدید با دو بخش
                    panel_buttons = InlineKeyboardMarkup(
                         [
                              # ردیف اول: دو بخش اصلی
                              [
                                   InlineKeyboardButton("دستورات سلف ⚙️", callback_data=f'self_commands-{user_id}')
                              ],
                              # ردیف آخر: دکمه بستن
                              [
                                   InlineKeyboardButton("✖️ بستن پنل", callback_data=f'closepanel-{user_id}')
                              ]
                         ]
                    )
                    
                    await app.edit_inline_text(
                         inline_message_id=call.inline_message_id,
                         text="**یکی از گزینه‌ها را انتخاب کنید:**",
                         reply_markup=panel_buttons
                    )
               
               # ============ سایر قابلیت‌ها ============
               else:
                    # دکمه‌های بازگشت برای بخش ساعت
                    back_to_saat = InlineKeyboardMarkup(
                         [
                              [
                                   InlineKeyboardButton("🪽 تنظیم بال ساعت", callback_data=f'balsaat-{user_id}')
                              ],
                              [
                                   InlineKeyboardButton("» بازگشت", callback_data=f'backtopanel-{user_id}')
                              ]
                         ]
                    )
                    
                    # دکمه بازگشت برای بال ساعت
                    back_from_bal = InlineKeyboardMarkup(
                         [
                              [
                                   InlineKeyboardButton("⏰ تنظیم فونت ساعت", callback_data=f'saat-{user_id}')
                              ],
                              [
                                   InlineKeyboardButton("» بازگشت", callback_data=f'backtopanel-{user_id}')
                              ]
                         ]
                    )
                    
                    # دکمه بازگشت عمومی (برای تمام بخش‌ها)
                    back_button = InlineKeyboardMarkup(
                         [
                              [
                                   InlineKeyboardButton("» بازگشت", callback_data=f'backtopanel-{user_id}')
                              ]
                         ]
                    )
          
                    if callback_type == "saat":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_saat, reply_markup=back_to_saat)
                    
                    elif callback_type == "balsaat":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_bal_saat, reply_markup=back_from_bal)
                    
                    elif callback_type == "riket":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_riket, reply_markup=back_button)
                    
                    elif callback_type == "spam":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_spam, reply_markup=back_button)
                    
                    elif callback_type == "download":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_download, reply_markup=back_button)
                    
                    elif callback_type == "logo":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_logo, reply_markup=back_button)
                    
                    elif callback_type == "game":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_game, reply_markup=back_button)
                    
                    elif callback_type == "convert":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_convert, reply_markup=back_button)
                    
                    elif callback_type == "management":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_management, reply_markup=back_button)
                    
                    elif callback_type == "sakot":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_sakot, reply_markup=back_button)
                    
                    elif callback_type == "enemyfriend":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_enemy_friend, reply_markup=back_button)
                    
                    elif callback_type == "pvlock":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_pvlock, reply_markup=back_button)
                    
                    elif callback_type == "secretary":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_secretary, reply_markup=back_button)
                    
                    elif callback_type == "filter":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_filter, reply_markup=back_button)
                    
                    elif callback_type == "timesave":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_timesave, reply_markup=back_button)
                    
                    elif callback_type == "texteffect":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_texteffect, reply_markup=back_button)
                    
                    elif callback_type == "autoseen":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_autoseen, reply_markup=back_button)
                    
                    elif callback_type == "action":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_action, reply_markup=back_button)
                    
                    elif callback_type == "tabchi":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_tabchi, reply_markup=back_button)
                    
                    elif callback_type == "diamond":
                         # متن کمک برای پینگ
                         diamond_help = """
╔═════════▣═════════╗

‌‌        ‌دستورات‌ ‌‌

─────────────────────

➤ `پینگ`  
⚡ سرعت پاسخ‌دهی سلف رو چک کن

─────────────────────
                         """
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=diamond_help, reply_markup=back_button)
                    
                    elif callback_type == "tools":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_tools, reply_markup=back_button)
                    
                    elif callback_type == "info":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_info, reply_markup=back_button)
                    
                    # ============ دکمه‌های جدید ============
                    elif callback_type == "antilogin":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_antilogin, reply_markup=back_button)
                    
                    elif callback_type == "online":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_online, reply_markup=back_button)
                    
                    elif callback_type == "clone":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_clone, reply_markup=back_button)
                    
                    elif callback_type == "delete":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_delete, reply_markup=back_button)
                    
                    elif callback_type == "animation":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_animation, reply_markup=back_button)
                    # ======================================
                    
                    elif callback_type == "closepanel":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text="**● پنل بسته شد ●**")
                    
                    elif callback_type == "Close":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text="**● Closed ●**")
          else:
               await call.answer("🚫 شما فقط می‌توانید به پنل خودتان دسترسی داشته باشید!", show_alert=True)
     else:
          await call.answer("این دکمه نمایشی است", show_alert=True)

@app.on_message(filters.private&filters.command("restart"), group=1)
async def updates(app, m:Message):
     OwnerUser = get_data(f"SELECT * FROM ownerlist WHERE id = '{m.chat.id}' LIMIT 1")
     if OwnerUser is not None:
          await app.send_message(m.chat.id, "**Helper Restart was successful**")
          python = sys.executable
          os.execl(python, python, *sys.argv)
          update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
    
@app.on_message(filters.private&filters.command("panel"))
async def updates(app, m:Message):
     OwnerUser = get_data(f"SELECT * FROM ownerlist WHERE id = '{m.chat.id}' LIMIT 1")
     if OwnerUser is not None:
          await app.send_message(m.chat.id, "**QuiteCreateCliBot Panel Owner**", reply_markup=keyboard_idk)
          update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
    
@app.on_message(filters.private&filters.command("start"))
async def updates(app, m:Message):
     # همه کاربران می‌توانند /start بزنند
     await app.send_message(m.chat.id, 
          f"""سلام {m.from_user.first_name} 👋

برای باز کردن پنل ، روی دکمه زیر کلیک کنید:
          """, 
          reply_markup=openpanelbot)
     
     update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")

# دستور پنل برای همه کاربران
@app.on_message(filters.private & (filters.regex('^پنل$') | filters.regex('^راهنما$')))
async def show_panel(app, m):
    await app.send_message(
        m.chat.id,
        "برای باز کردن پنل مدیریت، روی دکمه زیر کلیک کنید:",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🎛 باز کردن پنل", switch_inline_query_current_chat='panel')]
        ])
    )
   #______________________________Owner Panel________________________

Back = ReplyKeyboardMarkup(
     [
          [
               ("Back")
          ]
     ],resize_keyboard=True
)

@app.on_message(filters.private)
async def updates(app, m:Message):
 OwnerUser = get_data(f"SELECT * FROM ownerlist WHERE id = '{m.chat.id}' LIMIT 1")
 if OwnerUser is not None:
     user = get_data(f"SELECT * FROM user WHERE id = '{m.chat.id}' LIMIT 1")
     OwnerList = get_datas("SELECT * FROM ownerlist")
     AdminList = get_datas("SELECT * FROM adminlist")
     text = m.text

     if text == "Back":
          await app.send_message(m.chat.id, "**QuiteCreateCliBot Panel Owner**", reply_markup=keyboard_idk)
          update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")

     elif text == "Add Admin":
          await app.send_message(m.chat.id, "**Send Me User ID**:", reply_markup=Back)
          update_data(f"UPDATE user SET step = 'addadmin' WHERE id = '{m.chat.id}' LIMIT 1")

     elif user["step"] == "addadmin":
          if text.isdigit():
               user_id = int(text.strip())
               if get_data(f"SELECT * FROM adminlist WHERE id = '{user_id}' LIMIT 1") is None:
                    await app.send_message(m.chat.id, f"Successfull\nUser [ `{user_id}` ] Added to Admin List")
                    update_data(f"INSERT INTO adminlist(id) VALUES({user_id})")
               else:
                    await app.send_message(m.chat.id, "This user in the Admin list")
          else:
               await app.send_message(m.chat.id, "Invalid entry! Only sending numbers is allowed")

     elif text == "Delete Admin":
          await app.send_message(m.chat.id, "**Send Me User ID**:", reply_markup=Back)
          update_data(f"UPDATE user SET step = 'deladmin' WHERE id = '{m.chat.id}' LIMIT 1")

     elif user["step"] == "deladmin":
          if text.isdigit():
               user_id = int(text.strip())
               if get_data(f"SELECT * FROM adminlist WHERE id = '{user_id}' LIMIT 1") is not None:
                    await app.send_message(m.chat.id, f"Successfull\nUser [ `{user_id}` ] Deleted From User List")
                    update_data(f"DELETE FROM adminlist WHERE id = '{user_id}' LIMIT 1")
               else:
                    await app.send_message(m.chat.id, f"This user not in Admin list")
          else:
               await app.send_message(m.chat.id, "Invalid entry! Only sending numbers is allowed")
             
     elif text == "Admin List":
          s = ""
          if AdminList:
               for index, user in enumerate(AdminList, start=1):
                    s += f"֍ {index} -> `{user[0]}`\n"
               await app.send_message(m.chat.id, f"**Admin List:**\n{s}")
          else:
               await app.send_message(m.chat.id, f"**Admin List is Empty**")
          update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")

     elif text == "Add Owner":
          await app.send_message(m.chat.id, "**Send Me User ID**:", reply_markup=Back)
          update_data(f"UPDATE user SET step = 'addowner' WHERE id = '{m.chat.id}' LIMIT 1")

     elif user["step"] == "addowner":
          if text.isdigit():
               user_id = int(text.strip())
               if get_data(f"SELECT * FROM ownerlist WHERE id = '{user_id}' LIMIT 1") is None:
                    if get_data(f"SELECT * FROM adminlist WHERE id = '{user_id}' LIMIT 1") is not None:
                         await app.send_message(m.chat.id, f"Successfull\nUser [ `{user_id}` ] Added to Owner List")
                         update_data(f"INSERT INTO ownerlist(id) VALUES({user_id})")
                    else:
                         await app.send_message(m.chat.id, "ابتدا کاربر مورد نظر را به لیست ادمین اضافه کنید!")
               else:
                    await app.send_message(m.chat.id, "This user in the Owner list")
          else:
               await app.send_message(m.chat.id, "Invalid entry! Only sending numbers is allowed")

     elif text == "Delete Owner":
          await app.send_message(m.chat.id, "**Send Me User ID**:", reply_markup=Back)
          update_data(f"UPDATE user SET step = 'delowner' WHERE id = '{m.chat.id}' LIMIT 1")

     elif user["step"] == "delowner":
          if text.isdigit():
               user_id = int(text.strip())
               if get_data(f"SELECT * FROM ownerlist WHERE id = '{user_id}' LIMIT 1") is not None:
                    await app.send_message(m.chat.id, f"Successfull\nUser [ `{user_id}` ] Deleted From User List")
                    update_data(f"DELETE FROM ownerlist WHERE id = '{user_id}' LIMIT 1")
               else:
                    await app.send_message(m.chat.id, f"This user not in Owner list")
          else:
               await app.send_message(m.chat.id, "Invalid entry! Only sending numbers is allowed")
             
     elif text == "Owner List":
          s = ""
          if OwnerList:
               for index, user in enumerate(OwnerList, start=1):
                    s += f"֍ {index} -> `{user[0]}`\n"
               await app.send_message(m.chat.id, f"**Owner List:**\n{s}")
          else:
               await app.send_message(m.chat.id, f"**Owner List is Empty**")
          update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")

app.start(), print(Fore.YELLOW+"Started..."), idle(), app.stop()